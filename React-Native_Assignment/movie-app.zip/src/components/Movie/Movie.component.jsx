import React, { Component } from "react";
import { API_URL, API_KEY } from "../../config";
import Navigation from "../elements/Navigation/Navigation.component";
import MovieInfo from "../elements/MovieInfo/MovieInfo.component";
import MovieInfoBar from "../elements/MovieInfoBar/MovieInfoBar.component";
import Spinner from "../elements/Spinner/Spinner.component";
import "./Movie.styles.css";

import { Alert, Linking } from "react-native";

class Movie extends Component {
  state = {
    movie: null,
    directors: [],
    loading: false
  };

  componentDidMount() {
    const { movieId } = this.props.match.params;

    if (localStorage.getItem(`${movieId}`)) {
      let state = JSON.parse(localStorage.getItem(`${movieId}`));
      this.setState({ ...state });
    } else {
      this.setState({ loading: true });
      // First fetch the movie ...
      let endpoint = `${API_URL}movie/${movieId}?api_key=${API_KEY}&language=en-US`;
      this.fetchItems(endpoint);
    }
  }

  showAlert() {
    Alert.alert("You need to...");
  }

  fetchItems = (endpoint) => {
    const { movieId } = this.props.match.params;

    fetch(endpoint)
      .then((result) => result.json())
      .then((result) => {
        if (result.status_code) {
          // If we don't find any movie
          this.setState({ loading: false });
        } else {
          this.setState({ movie: result }, () => {
            // ... then fetch actors in the setState callback function
            let endpoint = `${API_URL}movie/${movieId}/credits?api_key=${API_KEY}`;
            fetch(endpoint)
              .then((result) => result.json())
              .then((result) => {
                const directors = result.crew.filter(
                  (member) => member.job === "Director"
                );

                this.setState(
                  {
                    directors,
                    loading: false
                  },
                  () => {
                    localStorage.setItem(
                      `${movieId}`,
                      JSON.stringify(this.state)
                    );
                  }
                );
              });
          });
        }
      })
      .catch((error) => console.error("Error:", error));
  };

  render() {
    const { movieName } = this.props.location;
    const { movie, directors, loading } = this.state;

    return (
      <div className="rmdb-movie">
        {movie ? (
          <div>
            <Navigation movie={movieName} />
            <MovieInfo movie={movie} directors={directors} />
            <MovieInfoBar
              time={movie.runtime}
              budget={movie.budget}
              revenue={movie.revenue}
            />
          </div>
        ) : null}

        {!loading ? <h1>No movie found</h1> : null}
        {loading ? <Spinner /> : null}
        <button className="btn" onPress={this.showAlert}>
          Click Me
        </button>
        <button
          className="btn"
          onClick={() => Linking.openURL("https://www.accolite.com")}
        >
          View details
        </button>
      </div>
    );
  }
}

export default Movie;
