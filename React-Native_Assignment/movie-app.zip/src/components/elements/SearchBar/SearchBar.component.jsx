import React, { Component } from "react";
import PropTypes from "prop-types";
import FontAwesome from "react-fontawesome";
import "./SearchBar.styles.css";

class SearchBar extends Component {
  state = {
    value: "",
    sortDirection: ""
  };
  timeout = null;

  doSearch = (event) => {
    const { callback } = this.props;

    this.setState({ value: event.target.value });
    clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      callback(this.state.value);
    }, 500);
  };
  sort1() {
    if (this.state.sortDirection === "descending") {
      this.setState({
        sortDirection: "ascending",
        data: this.props.value.sort(function (a, b) {
          return a.value - b.value;
        })
      });
    } else {
      this.setState({
        sortDirection: "descending",
        data: this.props.value.sort(function (a, b) {
          return b.value - b.value;
        })
      });
    }
  }
  doSort = (event) => {
    const { callback } = this.props;
    //var sortDirection = "descending";
    callback(this.state.value.sort1());
    //this.setState({ value: event.target.value });
    clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      callback(this.state.value);
    }, 500);
  };
  render() {
    const { value } = this.state;

    return (
      <div className="">
        <div className="">
          <FontAwesome className="" name="search" />
          <input
            type="text"
            className="rmdb-searchbar"
            placeholder="Search"
            onChange={this.doSearch}
            value={value}
          />
          <button className="btn2" onClick={this.doSearch}>
            X
          </button>
          <button className="btn2" onClick={this.doSort}>
            S
          </button>
        </div>
      </div>
    );
  }
}

SearchBar.propTypes = {
  callback: PropTypes.func
};

export default SearchBar;
