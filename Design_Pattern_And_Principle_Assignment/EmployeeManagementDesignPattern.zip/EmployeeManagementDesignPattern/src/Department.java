import java.util.List;

abstract class Department {

    public abstract void getName();
    private List<People> _employees;

}