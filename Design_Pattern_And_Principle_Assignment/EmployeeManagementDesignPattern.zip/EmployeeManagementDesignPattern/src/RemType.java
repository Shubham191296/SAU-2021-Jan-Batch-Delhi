
public interface RemType {

    void newSalary(double salary);
    void typeRem();

}
