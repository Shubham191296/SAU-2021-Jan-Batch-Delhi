
public class Service extends Department{

    @Override
    public void getName() {
        System.out.println("Welcome to Service Department");
    }
}
