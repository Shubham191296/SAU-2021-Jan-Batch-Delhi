public interface Management {

    void ManageEmpoloyee();

}
